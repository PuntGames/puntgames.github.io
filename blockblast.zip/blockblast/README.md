Block Blast puzzle but in your Browser. Optimized for speed and storage.
