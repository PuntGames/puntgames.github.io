The Chrome Dinosaur Game from when your wifi goes out, now unblocked and embedable.

Credits:
http://wayou.github.io/t-rex-runner/
Google - They made the game!

