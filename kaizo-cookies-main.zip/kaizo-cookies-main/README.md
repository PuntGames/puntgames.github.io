# Cookie Clicker (with Kaizo Cookies by [CursedSilver](https://github.com/CursedSliver/))
Download the .zip version to play Kaizo Cookies in a file at [here](https://github.com/plasma4/kaizo-cookies/archive/refs/heads/main.zip), and extract the .zip file first. Open index (or index.html) from the extracted folder to begin playing.
The original game can be found at http://orteil.dashnet.org/cookieclicker/

(This repo is itself a modified version of https://github.com/plasma4/cookieclicker/)