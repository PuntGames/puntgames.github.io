window.kaizo_load_local = true;
window.kaizo_load_externals_from_internal = true;
Game.heralds = 41;
setTimeout(() => { try { Game.LoadMod('./kaizo.js'); } catch { } }, 300);
