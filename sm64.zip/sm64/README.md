# Credit:
Code Borrowed from - 28klotlucas2 (https://github.com/28klotlucas2)
-
Code, originally, from - http://super-mario-64.surge.sh/
-
Super Mario 64 Created by - Nintendo (don´t sue me, please!)
-
I also have this available as its own repositroy, so if you want this by itself... here: https://github.com/CBGamesdev/SuperMario64Online 

If you want to know whats changed, I removed the top header that had the controls, it got annoying. 
Heres the controls by the way: 

Movement: Arrow Keys
-
A: X
-
B: C
-
L: Q
-
Z: Space
-
Start: Enter
-
C-stick: WASD
-

Have fun!

